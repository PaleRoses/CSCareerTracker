export { canManageJobs, ADMIN_ROLES, type AdminRole } from './permissions';
