import { CompaniesSkeleton } from '@/features/companies'

export default function CompaniesLoading() {
  return <CompaniesSkeleton />
}
