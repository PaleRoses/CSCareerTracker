import { CompanyDetailSkeleton } from '@/features/companies'

export default function CompanyLoading() {
  return <CompanyDetailSkeleton />
}
