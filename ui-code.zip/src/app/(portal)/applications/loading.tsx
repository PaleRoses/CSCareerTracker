import { ApplicationsSkeleton } from '@/features/applications/components/ApplicationsSkeleton'

export default function ApplicationsLoading() {
  return <ApplicationsSkeleton />
}
