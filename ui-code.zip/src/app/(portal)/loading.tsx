import { PortalSkeleton } from '@/features/shared/components/PortalSkeleton'

export default function PortalLoading() {
  return <PortalSkeleton />
}
