import { ReportsSkeleton } from '@/features/reports'

export default function ReportsLoading() {
  return <ReportsSkeleton />
}
