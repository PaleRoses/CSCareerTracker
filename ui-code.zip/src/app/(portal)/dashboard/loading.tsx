import { DashboardSkeleton } from '@/features/dashboard/components/DashboardSkeleton'

export default function DashboardLoading() {
  return <DashboardSkeleton />
}
