import { JobsSkeleton } from '@/features/jobs/components/JobsSkeleton'

export default function JobBrowserLoading() {
  return <JobsSkeleton />
}
