import RoleSelectionForm from '@/features/auth/components/RoleSelectionForm'

export default function SelectRolePage() {
  return <RoleSelectionForm />
}
