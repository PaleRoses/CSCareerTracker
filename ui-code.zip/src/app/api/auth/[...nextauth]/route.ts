import { handlers } from "@/features/auth/auth";

export const { GET, POST } = handlers;
