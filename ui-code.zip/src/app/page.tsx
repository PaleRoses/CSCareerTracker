import LoginForm from "@/features/auth/components/LoginForm";

export default function LoginPage() {
  return <LoginForm />;
}
